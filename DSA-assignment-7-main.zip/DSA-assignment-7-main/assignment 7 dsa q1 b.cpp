#include<iostream>
#include<climits>
using namespace std;
int main(){
    int n;
    cout<<"enter n : ";
    cin>>n;
    int arr[n];
    cout<<"enter "<<n<<" elements : ";
    for(int i=0;i<=n-1;i++){
        cin>>arr[i];
    }
    // insertion sort -> T.C.- O(n) and S.C.- O(1) -> stable sort
    for(int i=1;i<n;i++){
        int j = i;
        while(j>=1 && arr[j]<arr[j-1]){
            swap(arr[j],arr[j-1]);
            j--;
        }
    }
    cout<<"sorted array is : ";
    for(int i=0;i<n;i++){
            cout<<arr[i]<<" ";
        }
    return 0;
}