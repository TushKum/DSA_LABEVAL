#include <iostream>
#include <climits>
using namespace std;

int main() {
    int n;
    cout << "Enter n : ";
    cin >> n;

    int arr[n];
    cout << "Enter " << n << " elements : ";
    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int left = 0, right = n - 1;

    while(left < right) {

        int minIndex = left;
        int maxIndex = right;

        // Find minimum and maximum in current range
        for(int i = left; i <= right; i++) {
            if(arr[i] < arr[minIndex])
                minIndex = i;
            if(arr[i] > arr[maxIndex])
                maxIndex = i;
        }

        // Swap minimum element to left side
        int temp = arr[left];
        arr[left] = arr[minIndex];
        arr[minIndex] = temp;

        // If max element was at the left position, update its index
        if(maxIndex == left)
            maxIndex = minIndex;

        // Swap maximum element to right side
        temp = arr[right];
        arr[right] = arr[maxIndex];
        arr[maxIndex] = temp;

        left++;
        right--;
    }

    cout << "Sorted array is : ";
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}