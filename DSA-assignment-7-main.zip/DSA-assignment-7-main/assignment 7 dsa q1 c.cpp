#include<iostream>
#include<climits>
using namespace std;
int main(){
    int n;
    cout<<"enter n : ";
    cin>>n;
    int arr[n];
    cout<<"enter "<<n<<" elements : ";
    for(int i=0;i<=n-1;i++){
        cin>>arr[i];
    }
    // selection sort -> T.C. - O(n*n) and S.C. - O(1) -> unstable sort
    for(int i=0;i<n-1;i++){
        int min = INT_MAX;
        int mindx = -1;
        // min elt calculation
        for(int j=i;j<n;j++){
            if(arr[j]<min){
                min = arr[j];
                mindx = j;
            }
        }
        swap(arr[i],arr[mindx]);
    }
    cout<<"sorted array is : ";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}