#include <iostream>
using namespace std;

#define SIZE 5
int stk[SIZE];
int top = -1;

bool isEmpty() { return top == -1; }
bool isFull() { return top == SIZE - 1; }

void push(int val) {
    if (isFull()) {
        cout << "Stack Overflow! Cannot insert " << val << endl;
        return;
    }
    stk[++top] = val;
    cout << val << " pushed successfully!\n";
}

void pop() {
    if (isEmpty()) {
        cout << "Stack Underflow! Nothing to pop\n";
        return;
    }
    cout << stk[top--] << " popped successfully!\n";
}

void peek() {
    if (isEmpty())
        cout << "Stack empty, no top element\n";
    else
        cout << "Top element: " << stk[top] << endl;
}

void display() {
    if (isEmpty()) {
        cout << "Stack empty\n";
        return;
    }
    cout << "Stack (Top -> Bottom): ";
    for (int i = top; i >= 0; i--) cout << stk[i] << " ";
    cout << endl;
}

int main() {
    int choice, val;
    do {
        cout << "\n===== STACK MENU =====\n";
        cout << "1. Push\n2. Pop\n3. Check Empty\n4. Check Full\n5. Display\n6. Peek\n7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to push: ";
                cin >> val;
                push(val);
                break;
            case 2:
                pop();
                break;
            case 3:
                cout << (isEmpty() ? "Stack is Empty\n" : "Stack is not Empty\n");
                break;
            case 4:
                cout << (isFull() ? "Stack is Full\n" : "Stack is not Full\n");
                break;
            case 5:
                display();
                break;
            case 6:
                peek();
                break;
            case 7:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice!\n";
        }
    } while (choice != 7);

    return 0;
}
