#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *next;
};

Node *head = NULL;

void insertBegin() {
    int x;
    cout << "Enter value: ";
    cin >> x;
    Node *n = new Node{x, NULL};

    if (!head) { head = n; n->next = head; return; }

    Node *t = head;
    while (t->next != head) t = t->next;
    n->next = head;
    t->next = n;
    head = n;
}

void insertEnd() {
    int x;
    cout << "Enter value: ";
    cin >> x;
    Node *n = new Node{x, NULL};

    if (!head) { head = n; n->next = head; return; }

    Node *t = head;
    while (t->next != head) t = t->next;
    t->next = n;
    n->next = head;
}

void deleteNode() {
    int val;
    cout << "Enter value to delete: ";
    cin >> val;

    if (!head) return;

    Node *t = head, *prev = NULL;

    if (head->data == val) {
        while (t->next != head) t = t->next;
        if (t == head) { delete head; head = NULL; return; }
        t->next = head->next;
        delete head;
        head = t->next;
        return;
    }

    prev = head;
    t = head->next;

    while (t != head && t->data != val) { prev = t; t = t->next; }

    if (t == head) { cout << "Not found.\n"; return; }

    prev->next = t->next;
    delete t;
}

void searchNode() {
    int val, pos = 1;
    cout << "Enter value to search: ";
    cin >> val;

    if (!head) return;
    Node *t = head;
    do {
        if (t->data == val) { cout << "Found at position " << pos << endl; return; }
        pos++; t = t->next;
    } while (t != head);
    cout << "Not found.\n";
}

void display() {
    if (!head) { cout << "Empty.\n"; return; }
    Node *t = head;
    cout << "Circular List: ";
    do { cout << t->data << " "; t = t->next; }
    while (t != head);
    cout << endl;
}


int main() {
    int ch;
    while (true) {
        cout << "\n1.Insert Begin  2.Insert End  3.Delete Node  4.Search Node  5.Display  6.Exit\n";
		cout << "Enter choice: ";
        cin >> ch;

        if (ch == 1) insertBegin();
        else if (ch == 2) insertEnd();
        else if (ch == 3) deleteNode();
        else if (ch == 4) searchNode();
        else if (ch == 5) display();
        else break;
    }
}