#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* insertEnd(Node* head, int data) {
    Node* newNode = new Node();
    newNode->data = data;

    if(head == NULL) {
        newNode->next = newNode; // points to itself
        return newNode;
    }

    Node* temp = head;
    while(temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
    return head;
}

int sizeCircular(Node* head) {
    if(head == NULL) return 0;
    
    int count = 0;
    Node* temp = head;
    do {
        count++;
        temp = temp->next;
    } while(temp != head);

    return count;
}

int main() {
    Node* head = NULL;

    head = insertEnd(head, 10);
    head = insertEnd(head, 20);
    head = insertEnd(head, 30);

    cout << "Size of Circular Linked List: " << sizeCircular(head) << endl;
    return 0;
}