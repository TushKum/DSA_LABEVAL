#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *next, *prev;
};

Node *head = NULL;

void insertBegin() {
    int x;
    cout << "Enter value: ";
    cin >> x;
    Node *n = new Node{x, head, NULL};
    if (head != NULL) head->prev = n;
    head = n;
}

void insertEnd() {
    int x;
    cout << "Enter value: ";
    cin >> x;
    Node *n = new Node{x, NULL, NULL};
    if (!head) { head = n; return; }
    Node *t = head;
    while (t->next) t = t->next;
    t->next = n;
    n->prev = t;
}

void insertAfter() {
    int val, x;
    cout << "Insert after which value? ";
    cin >> val;
    cout << "Enter value to insert: ";
    cin >> x;
    Node *t = head;
    while (t && t->data != val) t = t->next;
    if (!t) { cout << "Node not found.\n"; return; }
    Node *n = new Node{x, t->next, t};
    if (t->next) t->next->prev = n;
    t->next = n;
}

void insertBefore() {
    int val, x;
    cout << "Insert before which value? ";
    cin >> val;
    cout << "Enter value to insert: ";
    cin >> x;

    if (!head) return;
    if (head->data == val) { insertBegin(); return; }

    Node *t = head;
    while (t && t->data != val) t = t->next;
    if (!t) { cout << "Node not found.\n"; return; }

    Node *n = new Node{x, t, t->prev};
    t->prev->next = n;
    t->prev = n;
}

void deleteNode() {
    int val;
    cout << "Enter value to delete: ";
    cin >> val;
    Node *t = head;

    while (t && t->data != val) t = t->next;
    if (!t) { cout << "Node not found.\n"; return; }

    if (t->prev) t->prev->next = t->next;
    else head = t->next;

    if (t->next) t->next->prev = t->prev;

    delete t;
    cout << "Node deleted.\n";
}

void searchNode() {
    int val, pos = 1;
    cout << "Enter value to search: ";
    cin >> val;
    Node *t = head;
    while (t) {
        if (t->data == val) {
            cout << "Found at position " << pos << endl;
            return;
        }
        pos++;
        t = t->next;
    }
    cout << "Not found.\n";
}

void display() {
    Node *t = head;
    cout << "Doubly List: ";
    while (t) { cout << t->data << " "; t = t->next; }
    cout << endl;
}

int main() {
    int ch;
    while (true) {
        cout << "\n1.Insert Begin  2.Insert End  3.Insert After  4.Insert Before  5.Delete Node  6.Search Node  7.Display  8.Exit\n";
		cout << "Enter choice : ";
        cin >> ch;

        if (ch == 1) insertBegin();
        else if (ch == 2) insertEnd();
        else if (ch == 3) insertAfter();
        else if (ch == 4) insertBefore();
        else if (ch == 5) deleteNode();
        else if (ch == 6) searchNode();
        else if (ch == 7) display();
        else break;
    }