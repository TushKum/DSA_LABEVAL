#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *prev, *next;
};

Node* insertEnd(Node* head, int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->prev = newNode->next = NULL;

    if(head == NULL)
        return newNode;

    Node* temp = head;
    while(temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
    return head;
}

int sizeDoubly(Node* head) {
    int count = 0;
    while(head != NULL) {
        count++;
        head = head->next;
    }
    return count;
}

int main() {
    Node* head = NULL;
    
    head = insertEnd(head, 10);
    head = insertEnd(head, 20);
    head = insertEnd(head, 30);

    cout << "Size of Doubly Linked List: " << sizeDoubly(head) << endl;
    return 0;