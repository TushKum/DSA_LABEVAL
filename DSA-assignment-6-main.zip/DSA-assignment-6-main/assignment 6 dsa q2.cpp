#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *next;
};

Node *head = NULL;

void insertEnd(int value) {
    Node *newNode = new Node{value, NULL};

    if (head == NULL) {
        head = newNode;
        newNode->next = head;
        return;
    }

    Node *temp = head;
    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
}

void displayWithRepeat() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Node *temp = head;

    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    //repeat head value
    cout << head->data << endl;
}

int main() {
    insertEnd(20);
    insertEnd(100);
    insertEnd(40);
    insertEnd(80);
    insertEnd(60);

    cout << "Output: ";
    displayWithRepeat();   

    return 0;